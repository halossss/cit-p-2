/*
project: p2
name: Noah berkstresser
*/ 
function getRandomInteger(min, max) {
    return Math.floor(Math.random() * (max - min) + min);
  }
  
  const alphabet = "abcdefghijklmnopqrstuvwxyz".split("");
  let result = "";
  
  for (let i = 0; i < getRandomInteger(5, 26); i++) {
    result += alphabet[getRandomInteger(1, alphabet.length - 1)];
    result2 = getRandomLetter();
  }
  
  console.log("getRandomInteger: "+ result + " getRandomLetter: " + result2);

  //returns a sinlge random lowercase letter
function getRandomLetter() {
    return alphabet[getRandomInteger(1, alphabet.length - 1)];
  }

  // This function generates a random string of variable length between minLength and maxLength (inclusive)
  function getRandomString(minLength, maxLength) {
    const length = getRandomInteger(minLength, maxLength);
    let result = "";

    for (let i = 0; i < length; i++) {
      result += getRandomLetter();
    }

    return result;
  }
  console.log("getRandomString: " + getRandomString(10, 20));

  //takes the result of the for loop and sorts it alphabetically
  const getSortedString = string => string.split("").sort().join("");

  console.log("getSortedString: " + getSortedString(result));
  